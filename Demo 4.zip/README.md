
  # Demo 4

  This is a code bundle for Demo 4. The original project is available at https://www.figma.com/design/mhxLaWMN6EMQ0d8Dgz3ntE/Demo-4.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  