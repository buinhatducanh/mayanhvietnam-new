
  # Thiết kế dự án theo ảnh

  This is a code bundle for Thiết kế dự án theo ảnh. The original project is available at https://www.figma.com/design/bcBqxmA2mu3CkswVqciyMv/Thi%E1%BA%BFt-k%E1%BA%BF-d%E1%BB%B1-%C3%A1n-theo-%E1%BA%A3nh.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  