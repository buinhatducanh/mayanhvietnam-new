import { createBrowserRouter } from "react-router";
import Root from "@/app/layout/Root";
import Home from "@/app/pages/Home";
import ProductDetail from "@/app/pages/ProductDetail";
import Cart from "@/app/pages/Cart";

function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center py-32 gap-4 text-center">
      <p className="text-8xl font-black text-zinc-100">404</p>
      <p className="text-zinc-500 font-medium">Trang không tồn tại</p>
      <a href="/" className="text-[#ff6b00] hover:underline text-sm flex items-center gap-1">← Về trang chủ</a>
    </div>
  );
}

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: "product/canon-eos-r50", Component: ProductDetail },
      { path: "cart", Component: Cart },
      { path: "*", Component: NotFound },
    ],
  },
]);
