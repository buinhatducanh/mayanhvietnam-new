import { useState, useEffect } from "react";
import {
  Sun, Moon, Search, ShoppingCart, User, ChevronRight,
  Star, Truck, ShieldCheck, Award, Wifi, Zap, Eye,
  RotateCcw, Camera, Menu, X, Heart, SlidersHorizontal,
} from "lucide-react";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";
import heroDark from "@/imports/image.png";
import heroLight from "@/imports/image-1.png";

// ─── Product data ─────────────────────────────────────────────────────────────

const HERO = {
  badge: "NEW ARRIVAL",
  name: "Canon EOS R6 Mark II",
  tagline: "Hiệu suất đỉnh cao. Sáng tạo không giới hạn.",
  price: 49990000,
  originalPrice: 54900000,
  specs: [
    { icon: Camera, label: "24.2MP", sub: "Full Frame" },
    { icon: Zap, label: "8K", sub: "Video" },
    { icon: Eye, label: "AI FOCUS", sub: "Dual Pixel" },
    { icon: Wifi, label: "Wi-Fi 6", sub: "Bluetooth" },
  ],
  features: ["360° View", "4K Video", "IBIS 8-stop", "30fps Burst"],
  img: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=900&h=900&fit=crop&auto=format",
};

const THUMBS = [
  "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=120&h=120&fit=crop&auto=format",
  "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=120&h=120&fit=crop&auto=format",
  "https://images.unsplash.com/photo-1606986628253-d3bd1d2d0e9c?w=120&h=120&fit=crop&auto=format",
  "https://images.unsplash.com/photo-1573868396651-ca8a5fca84f6?w=120&h=120&fit=crop&auto=format",
  "https://images.unsplash.com/photo-1542038784456-1ea8e935640e?w=120&h=120&fit=crop&auto=format",
];

const PRODUCTS = [
  {
    id: 1, brand: "Canon", name: "Canon EOS R6 Mark II", category: "Mirrorless",
    price: 49990000, originalPrice: 54900000, badge: "HOT",
    rating: 4.9, reviews: 312,
    img: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=400&h=400&fit=crop&auto=format",
  },
  {
    id: 2, brand: "Sony", name: "Sony A7 IV", category: "Mirrorless",
    price: 64000000, originalPrice: null, badge: "NEW",
    rating: 4.8, reviews: 187,
    img: "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=400&fit=crop&auto=format",
  },
  {
    id: 3, brand: "Canon", name: "Canon RF 24-70mm f/2.8L IS", category: "Lens",
    price: 73990000, originalPrice: 79000000, badge: null,
    rating: 4.7, reviews: 94,
    img: "https://images.unsplash.com/photo-1606986628253-d3bd1d2d0e9c?w=400&h=400&fit=crop&auto=format",
  },
  {
    id: 4, brand: "Sony", name: "Sony FE 200-600mm f/5.6-6.3G", category: "Lens",
    price: 47000000, originalPrice: 52000000, badge: "SALE",
    rating: 4.8, reviews: 63,
    img: "https://images.unsplash.com/photo-1573868396651-ca8a5fca84f6?w=400&h=400&fit=crop&auto=format",
  },
  {
    id: 5, brand: "DJI", name: "DJI Mini Pro 4", category: "Flycam",
    price: 20990000, originalPrice: null, badge: "NEW",
    rating: 4.6, reviews: 241,
    img: "https://images.unsplash.com/photo-1473968512647-3e447244af8f?w=400&h=400&fit=crop&auto=format",
  },
];

const NAV_LINKS = ["Trang chủ", "Sản phẩm", "Thương hiệu", "Tin tức", "Liên hệ"];

const TRUST = [
  { icon: Truck, title: "Giao hàng toàn quốc", desc: "Miễn phí đơn từ 500K, giao tận nơi" },
  { icon: ShieldCheck, title: "Sản phẩm chính hãng", desc: "Cam kết 100% hàng chính hãng" },
  { icon: Award, title: "Bảo hành 24 tháng", desc: "Hỗ trợ đổi trả trong 30 ngày" },
  { icon: ShoppingCart, title: "Thanh toán dễ dàng", desc: "Ví điện tử, thẻ, trả góp 0%" },
];

const vnd = (n: number) => n.toLocaleString("vi-VN") + " VND";

const BADGE_COLOR: Record<string, string> = {
  HOT: "bg-red-500",
  NEW: "bg-blue-500",
  SALE: "bg-emerald-600",
};

// ─── Components ───────────────────────────────────────────────────────────────

function StarRow({ rating, reviews }: { rating: number; reviews: number }) {
  return (
    <div className="flex items-center gap-1.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <Star key={i} size={11}
          fill={i <= Math.floor(rating) ? "#FF6B35" : "none"}
          style={{ color: "#FF6B35" }} />
      ))}
      <span className="text-[11px] font-mono text-muted-foreground ml-1">({reviews})</span>
    </div>
  );
}

function ProductCard({ p, dark }: { p: typeof PRODUCTS[0]; dark: boolean }) {
  const [hovered, setHovered] = useState(false);
  const discount = p.originalPrice
    ? Math.round((1 - p.price / p.originalPrice) * 100)
    : null;

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="group rounded-2xl overflow-hidden border border-border bg-card transition-all duration-300 cursor-pointer"
      style={hovered
        ? { borderColor: "rgba(255,107,53,0.45)", boxShadow: dark ? "0 0 24px rgba(255,107,53,0.12)" : "0 8px 32px rgba(255,107,53,0.1)" }
        : {}}
    >
      {/* Image */}
      <div className="relative overflow-hidden bg-muted"
        style={{ aspectRatio: "1 / 1" }}>
        <img src={p.img} alt={p.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.07]" />

        {/* Badges */}
        <div className="absolute top-2.5 left-2.5 flex gap-1.5">
          {p.badge && (
            <span className={`${BADGE_COLOR[p.badge]} text-white text-[9px] font-mono font-bold tracking-widest px-2 py-0.5 rounded-sm`}>
              {p.badge}
            </span>
          )}
          {discount && (
            <span className="bg-emerald-600 text-white text-[9px] font-mono font-bold px-2 py-0.5 rounded-sm">
              -{discount}%
            </span>
          )}
        </div>

        {/* Wishlist */}
        <button className="absolute top-2.5 right-2.5 w-7 h-7 rounded-full bg-background/70 border border-border backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:border-accent">
          <Heart size={12} />
        </button>

        {/* Hover gradient */}
        {hovered && (
          <div className="absolute bottom-0 left-0 right-0 h-1/3 pointer-events-none"
            style={{ background: "linear-gradient(to top, rgba(255,107,53,0.12), transparent)" }} />
        )}
      </div>

      {/* Info */}
      <div className="p-4 space-y-2">
        <p className="text-[10px] font-mono tracking-widest text-muted-foreground uppercase">
          {p.brand} · {p.category}
        </p>
        <h3 className="text-sm font-semibold leading-snug line-clamp-2"
          style={{ fontFamily: "'Playfair Display', serif" }}>
          {p.name}
        </h3>
        <StarRow rating={p.rating} reviews={p.reviews} />
        <div className="pt-1">
          <span className="font-mono font-bold text-base" style={{ color: "#FF6B35" }}>
            {vnd(p.price)}
          </span>
          {p.originalPrice && (
            <span className="ml-2 text-xs font-mono text-muted-foreground line-through">
              {vnd(p.originalPrice)}
            </span>
          )}
        </div>
        <button
          className="w-full mt-2 py-2 rounded-lg text-sm font-semibold text-white transition-all hover:opacity-90 active:scale-95"
          style={{ background: "#FF6B35" }}>
          Xem chi tiết
        </button>
      </div>
    </div>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [dark, setDark] = useState(true);
  const [activeThumb, setActiveThumb] = useState(0);
  const [mobileNav, setMobileNav] = useState(false);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);

  return (
    <div className="min-h-screen bg-background text-foreground transition-colors duration-300"
      style={{ fontFamily: "'Inter', sans-serif" }}>

      {/* ── NAV ──────────────────────────────────────────────────────────── */}
      <nav className="sticky top-0 z-50 border-b border-border bg-background/90 backdrop-blur-xl">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 h-14 flex items-center gap-4">

          {/* Logo */}
          <div className="flex items-center gap-2 flex-shrink-0">
            <div className="w-7 h-7 rounded flex items-center justify-center"
              style={{ background: "#FF6B35", boxShadow: dark ? "0 0 10px rgba(255,107,53,0.5)" : "none" }}>
              <Camera size={14} className="text-white" />
            </div>
            <div className="flex flex-col leading-none">
              <span className="text-[10px] font-mono font-bold tracking-[0.2em] text-foreground">CAMERA</span>
              <span className="text-[8px] font-mono tracking-[0.3em] text-muted-foreground">STORE</span>
            </div>
          </div>

          {/* Desktop nav links */}
          <div className="hidden md:flex items-center gap-1 flex-1 justify-center">
            {NAV_LINKS.map((link, i) => (
              <button key={link}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                  i === 1
                    ? "text-accent font-semibold"
                    : "text-muted-foreground hover:text-foreground"
                }`}
                style={i === 1 ? { color: "#FF6B35" } : {}}>
                {link}
              </button>
            ))}
          </div>

          {/* Search */}
          <div className="hidden sm:flex items-center gap-2 flex-shrink-0">
            <div className="relative">
              <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                placeholder="Tìm kiếm sản phẩm..."
                className="pl-8 pr-4 py-1.5 text-xs rounded-lg border border-border bg-card text-foreground placeholder:text-muted-foreground focus:outline-none w-44 transition-all"
                style={{ caretColor: "#FF6B35" }}
                onFocus={(e) => { e.currentTarget.style.borderColor = "rgba(255,107,53,0.5)"; e.currentTarget.style.width = "200px"; }}
                onBlur={(e) => { e.currentTarget.style.borderColor = ""; e.currentTarget.style.width = ""; }}
              />
            </div>
          </div>

          <div className="flex items-center gap-2 ml-auto">
            <button className="relative p-2 rounded-lg border border-border hover:border-accent transition-colors">
              <ShoppingCart size={15} />
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full text-white text-[9px] font-bold flex items-center justify-center"
                style={{ background: "#FF6B35" }}>3</span>
            </button>
            <button className="p-2 rounded-lg border border-border hover:border-accent transition-colors">
              <User size={15} />
            </button>
            <button onClick={() => setDark(!dark)}
              className="p-2 rounded-lg border border-border hover:border-accent transition-colors"
              style={dark ? { borderColor: "rgba(255,107,53,0.3)" } : {}}>
              {dark ? <Sun size={14} style={{ color: "#FF6B35" }} /> : <Moon size={14} />}
            </button>
            <button onClick={() => setMobileNav(!mobileNav)}
              className="md:hidden p-2 rounded-lg border border-border">
              {mobileNav ? <X size={15} /> : <Menu size={15} />}
            </button>
          </div>
        </div>

        {/* Mobile nav */}
        {mobileNav && (
          <div className="md:hidden border-t border-border bg-background px-4 py-3 flex flex-col gap-1">
            {NAV_LINKS.map((link) => (
              <button key={link} className="text-left px-3 py-2 text-sm text-muted-foreground hover:text-foreground rounded-md hover:bg-muted/50 transition-colors">
                {link}
              </button>
            ))}
          </div>
        )}
      </nav>

      {/* ── HERO ─────────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden border-b border-border">
        {/* Background glow */}
        <div className="absolute inset-0 pointer-events-none"
          style={{
            background: dark
              ? "radial-gradient(ellipse 80% 60% at 60% 40%, rgba(255,107,53,0.15) 0%, transparent 65%)"
              : "radial-gradient(ellipse 80% 60% at 60% 40%, rgba(255,107,53,0.08) 0%, transparent 65%)",
          }} />
        {dark && (
          <div className="absolute inset-0 pointer-events-none opacity-[0.025]"
            style={{ backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 2px, #fff 2px, #fff 3px)" }} />
        )}

        <div className="relative max-w-[1280px] mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-[auto_1fr_auto] gap-0 items-center min-h-[520px] sm:min-h-[580px]">

            {/* Left: Thumbnails */}
            <div className="hidden lg:flex flex-col gap-2 py-10 pr-5 w-[72px]">
              {THUMBS.map((src, i) => (
                <button key={i} onClick={() => setActiveThumb(i)}
                  className="w-14 h-14 rounded-xl overflow-hidden border-2 flex-shrink-0 transition-all duration-200"
                  style={i === activeThumb
                    ? { borderColor: "#FF6B35", boxShadow: dark ? "0 0 10px rgba(255,107,53,0.5)" : "0 0 8px rgba(255,107,53,0.3)", opacity: 1 }
                    : { borderColor: "transparent", opacity: 0.45 }}>
                  <img src={src} alt="" className="w-full h-full object-cover bg-muted" />
                </button>
              ))}
            </div>

            {/* Center: Product on pedestal */}
            <div className="relative flex items-center justify-center py-8 sm:py-12 order-first lg:order-none">
              {/* Pedestal glow */}
              <div className="absolute bottom-8 left-1/2 -translate-x-1/2 pointer-events-none"
                style={{
                  width: "340px", height: "80px",
                  background: dark
                    ? "radial-gradient(ellipse, rgba(255,107,53,0.6) 0%, transparent 70%)"
                    : "radial-gradient(ellipse, rgba(255,107,53,0.2) 0%, transparent 70%)",
                  filter: "blur(20px)",
                }} />
              {/* Orange glow ring */}
              {dark && (
                <div className="absolute bottom-12 left-1/2 -translate-x-1/2 pointer-events-none"
                  style={{
                    width: "280px", height: "20px",
                    background: "radial-gradient(ellipse, rgba(255,107,53,0.9) 0%, transparent 70%)",
                    filter: "blur(8px)",
                  }} />
              )}
              {/* Platform disc */}
              {!dark && (
                <div className="absolute bottom-10 left-1/2 -translate-x-1/2 pointer-events-none"
                  style={{
                    width: "300px", height: "32px",
                    background: "radial-gradient(ellipse, rgba(200,180,160,0.4) 0%, transparent 70%)",
                    filter: "blur(10px)",
                  }} />
              )}

              {/* Product image */}
              <img
                key={activeThumb}
                src={THUMBS[activeThumb].replace("w=120&h=120", "w=700&h=700")}
                alt={HERO.name}
                className="relative z-10 w-full max-w-[360px] sm:max-w-[440px] object-contain transition-all duration-500"
                style={{
                  filter: dark
                    ? "drop-shadow(0 20px 60px rgba(255,107,53,0.3)) drop-shadow(0 0 80px rgba(255,107,53,0.1))"
                    : "drop-shadow(0 20px 50px rgba(0,0,0,0.15))",
                }}
              />
            </div>

            {/* Right: Copy + specs */}
            <div className="lg:pl-8 xl:pl-12 py-10 max-w-sm lg:max-w-[360px]">
              <span className="inline-block text-[10px] font-mono font-bold tracking-[0.25em] px-3 py-1 rounded-sm mb-4 uppercase"
                style={{ background: "rgba(255,107,53,0.15)", color: "#FF6B35", border: "1px solid rgba(255,107,53,0.3)" }}>
                {HERO.badge}
              </span>

              <h1 className="text-3xl sm:text-4xl font-black leading-tight mb-2"
                style={{ fontFamily: "'Playfair Display', serif" }}>
                {HERO.name}
              </h1>
              <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
                {HERO.tagline}
              </p>

              {/* Spec grid */}
              <div className="grid grid-cols-4 gap-2 mb-6">
                {HERO.specs.map(({ icon: Icon, label, sub }) => (
                  <div key={label}
                    className="flex flex-col items-center gap-1 py-2.5 rounded-xl border border-border bg-card text-center"
                    style={dark ? { background: "rgba(255,255,255,0.04)" } : {}}>
                    <Icon size={14} style={{ color: "#FF6B35" }} />
                    <span className="text-xs font-mono font-bold text-foreground">{label}</span>
                    <span className="text-[9px] font-mono text-muted-foreground leading-tight">{sub}</span>
                  </div>
                ))}
              </div>

              {/* Price */}
              <div className="mb-5">
                <p className="text-2xl sm:text-3xl font-mono font-black" style={{ color: "#FF6B35" }}>
                  {vnd(HERO.price)}
                </p>
                {HERO.originalPrice && (
                  <p className="text-sm font-mono text-muted-foreground line-through mt-0.5">
                    {vnd(HERO.originalPrice)}
                  </p>
                )}
              </div>

              {/* CTAs */}
              <div className="flex gap-2.5">
                <button
                  className="flex-1 py-3 rounded-xl text-white font-semibold text-sm transition-all hover:opacity-90 active:scale-95 flex items-center justify-center gap-2"
                  style={{ background: "#FF6B35", boxShadow: dark ? "0 0 24px rgba(255,107,53,0.4)" : "0 4px 16px rgba(255,107,53,0.3)" }}>
                  <ShoppingCart size={15} />
                  Mua ngay
                </button>
                <button
                  className="flex-1 py-3 rounded-xl font-semibold text-sm transition-all border hover:border-accent flex items-center justify-center gap-2"
                  style={{ borderColor: "rgba(255,107,53,0.4)", color: "#FF6B35" }}>
                  <Heart size={15} />
                  Thêm vào giỏ
                </button>
              </div>

              {/* Feature tags */}
              <div className="flex flex-wrap gap-1.5 mt-4">
                {HERO.features.map((f) => (
                  <span key={f}
                    className="text-[10px] font-mono text-muted-foreground border border-border rounded-md px-2 py-0.5">
                    {f}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right-edge feature icons — desktop only */}
        <div className="hidden xl:flex absolute right-4 top-1/2 -translate-y-1/2 flex-col gap-3">
          {[
            { icon: RotateCcw, label: "360°" },
            { icon: Zap, label: "8K" },
            { icon: Eye, label: "AI AF" },
            { icon: SlidersHorizontal, label: "IBIS" },
            { icon: Wifi, label: "Wi-Fi" },
          ].map(({ icon: Icon, label }) => (
            <div key={label}
              className="flex flex-col items-center gap-1 w-10 opacity-60 hover:opacity-100 transition-opacity cursor-pointer">
              <div className="w-8 h-8 rounded-lg border border-border bg-card flex items-center justify-center"
                style={dark ? { background: "rgba(255,255,255,0.05)" } : {}}>
                <Icon size={13} style={{ color: "#FF6B35" }} />
              </div>
              <span className="text-[8px] font-mono text-muted-foreground">{label}</span>
            </div>
          ))}
        </div>
      </section>

      {/* ── TRUST STRIP ──────────────────────────────────────────────────── */}
      <section className="border-b border-border">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 divide-x divide-border">
            {TRUST.map(({ icon: Icon, title, desc }) => (
              <div key={title} className="flex items-start gap-3 py-4 px-4">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5"
                  style={{ background: "rgba(255,107,53,0.1)" }}>
                  <Icon size={16} style={{ color: "#FF6B35" }} />
                </div>
                <div>
                  <p className="text-xs font-semibold text-foreground">{title}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5 leading-snug">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FEATURED PRODUCTS ────────────────────────────────────────────── */}
      <section className="py-10 sm:py-14">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          {/* Section header */}
          <div className="flex items-end justify-between mb-7">
            <div>
              <p className="text-[10px] font-mono tracking-[0.2em] text-muted-foreground uppercase mb-1">
                Bộ sưu tập
              </p>
              <h2 className="text-2xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>
                Sản phẩm nổi bật
              </h2>
            </div>
            <button
              className="hidden sm:flex items-center gap-1.5 text-xs font-medium transition-colors hover:opacity-80"
              style={{ color: "#FF6B35" }}>
              Xem tất cả <ChevronRight size={13} />
            </button>
          </div>

          {/* Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
            {PRODUCTS.map((p) => (
              <ProductCard key={p.id} p={p} dark={dark} />
            ))}
          </div>

          <div className="flex sm:hidden justify-center mt-5">
            <button
              className="px-6 py-2.5 rounded-xl border text-sm font-medium flex items-center gap-2 transition-colors hover:border-accent"
              style={{ color: "#FF6B35", borderColor: "rgba(255,107,53,0.4)" }}>
              Xem tất cả <ChevronRight size={13} />
            </button>
          </div>
        </div>
      </section>

      {/* ── REFERENCE SCREENSHOTS (Commerce Observer context) ────────────── */}
      <section className="border-t border-border py-10 sm:py-14 bg-muted/30">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
          <div className="mb-6">
            <p className="text-[10px] font-mono tracking-[0.2em] text-muted-foreground uppercase mb-1">
              Commerce Observer · Design Reference
            </p>
            <h2 className="text-xl font-bold" style={{ fontFamily: "'Playfair Display', serif" }}>
              Dual-mode Design System
            </h2>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="rounded-2xl overflow-hidden border border-border shadow-xl">
              <div className="px-3 py-2 border-b border-border bg-card flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-red-500" />
                <div className="w-2 h-2 rounded-full bg-amber-500" />
                <div className="w-2 h-2 rounded-full bg-green-500" />
                <span className="text-[10px] font-mono text-muted-foreground ml-2">Dark Pro Mode</span>
              </div>
              <ImageWithFallback src={heroDark} alt="Camera Store Dark Pro — dark immersive mode reference"
                className="w-full object-cover" />
            </div>
            <div className="rounded-2xl overflow-hidden border border-border shadow-xl">
              <div className="px-3 py-2 border-b border-border bg-card flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-red-500" />
                <div className="w-2 h-2 rounded-full bg-amber-500" />
                <div className="w-2 h-2 rounded-full bg-green-500" />
                <span className="text-[10px] font-mono text-muted-foreground ml-2">Light Warm Mode</span>
              </div>
              <ImageWithFallback src={heroLight} alt="Camera Store Light — warm cream mode reference"
                className="w-full object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* ── FOOTER ───────────────────────────────────────────────────────── */}
      <footer className="border-t border-border py-8">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded flex items-center justify-center"
              style={{ background: "#FF6B35" }}>
              <Camera size={12} className="text-white" />
            </div>
            <span className="text-xs font-mono font-bold tracking-widest text-muted-foreground">CAMERA STORE</span>
          </div>
          <p className="text-[10px] font-mono text-muted-foreground text-center">
            4 cửa hàng tại HCM · Hà Nội · Đà Nẵng · Cần Thơ &nbsp;·&nbsp; Hotline: 1800 6789
          </p>
          <p className="text-[10px] font-mono text-muted-foreground">
            © 2025 Camera Store VN
          </p>
        </div>
      </footer>
    </div>
  );
}
