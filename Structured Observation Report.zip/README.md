
  # Structured Observation Report

  This is a code bundle for Structured Observation Report. The original project is available at https://www.figma.com/design/mhxLaWMN6EMQ0d8Dgz3ntE/Structured-Observation-Report.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  